const {createClient}=require("@supabase/supabase-js");
const db=createClient(process.env.SUPABASE_URL,process.env.SUPABASE_SERVICE_ROLE_KEY,{auth:{persistSession:false}});
const ok=req=>req.headers["x-admin-password"]===process.env.ADMIN_PASSWORD;
module.exports=async(req,res)=>{
 try{
  res.setHeader("Cache-Control","no-store");
  if(req.method==="GET"){
   const d=new Date().toISOString().slice(0,10);
   const {data,error}=await db.from("rates").select("*").lte("valid_from",d)
    .or(`valid_to.is.null,valid_to.gte.${d}`).order("valid_from",{ascending:false}).limit(1).maybeSingle();
   if(error)throw error; return res.status(200).json({rate:data});
  }
  if(req.method!=="POST"||!ok(req))return res.status(401).json({error:"No autorizado"});
  const b=req.body||{};
  if(b.action==="history"){
   const {data,error}=await db.from("rates").select("*").order("valid_from",{ascending:false}).limit(100);
   if(error)throw error; return res.json({rates:data});
  }
  if(b.action==="save"){
   const r=b.rate;
   const row={co_ve:+r.coVe,ve_co:+r.veCo,usd_colombia:+r.usdColombia,usd_venezuela:+r.usdVenezuela,
    valid_from:r.validFrom,valid_to:r.validTo||null,notes:r.notes||""};
   if(!row.valid_from||[row.co_ve,row.ve_co,row.usd_colombia,row.usd_venezuela].some(x=>!(x>0)))
    return res.status(400).json({error:"Revisa los datos de la tasa"});
   const {data,error}=await db.from("rates").insert(row).select("*").single();
   if(error)throw error; return res.json({rate:data});
  }
  return res.status(400).json({error:"Acción inválida"});
 }catch(e){console.error(e);return res.status(500).json({error:"Error de servidor/Supabase"});}
};